# Exemplos

Todos os exemplos foram feitos em um unico arquivo : "Exemplo0200.c" .

# Exercicios

Todos os exercicos foram feitos em um unico arquivo : "Exercicios02.c" .