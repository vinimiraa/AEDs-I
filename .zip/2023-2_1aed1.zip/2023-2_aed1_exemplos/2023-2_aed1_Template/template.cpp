/**
  Program v0.0
  @author
  @version
  @date
*/

// lista de dependencias
#include <cstdio>      // para entradas e saida
#include <cstdlib>     // para a biblioteca padrao
#include <cstring>     // para cadeias de caracteres
#include <cmath>       // para definicoes matematicas
#include <time.h>      // para medir tempo

#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>

/**
  Acao principal.
*/
int main ( void )
{
 // definir dados/resultados

 // identificar
    std::cout << "Programa - versao 0.0 - 20xx\n";
    std::cout << "999999 - XXX\n";
    std::cout << std::endl;

 // acoes

 // encerrar
    std::cout << "\nApertar ENTER para terminar.\n";
    std::cin.get( );
    return ( 0 );
} // fim main ( )

/*

// Function: ...
int function (int parameter)
{
  int result = 0;
  //
  return ( result );
}

// Procedure: ...
void procedure ( )
{
  //
}

// Data: ...
char   c = '0'; //

double d = 0.0; //

float  f = 0.0; //

int    x =  0 ; //

char s[80];     //

std::string str;     // (C++ native )

class st_data { public: int a, double b };

st_data  sd;
d.a      = 0; sd.b      = 0.0;

st_data *psd = new st_data( ); // constructor
psd->a = 0; psd->b = 0;

// Test: ...
if ( 1 )
{
  ; //
}

if ( 0 )
{
  ; //
}
else
{
  ; //
}

switch ( 0 )
{
  case 0:
    ; //
   break;
  default:
    ; //
}

// Loop: ...
while ( 1 )
{
  ; //
}

do
{
  ; //
}
while ( 1 );

for (x=0; x<1; x=x+1)
{
  ; //
}

// Input: ...
std::cin >> c;

std::cin >> d;

std::cin >> f;

std::cin >> x;

std::cin >> s;

// Output: ...
std::cout << "\n";
std::cout << std::endl;

std::cout << "c=" << c << "\n";

std::cout << "d=" << d << "\n";

std::cout << "f=" << f << "\n";

std::cout << "x=" << x << "\n";

std::cout << "c=" << c << "\n";

std::cout << "s=" << s << "\n";

// Files: ...
ifstream afile ( "INPUT.TXT"  );
fstream  afile ( "INPUT.TXT"  , std::ios::in  );

ofstream afile ( "OUTPUT.TXT" );
fstream  afile ( "OUTPUT.TXT" , std::ios::out );

// File input:
afile >> c;

afile >> d;

afile >> f;

afile >> x;

afile >> s;

// File output: ...
afile << "\n";
afile << std::endl;

afile << "c=" << c << "\n";

afile << "d=" << d << "\n";

afile << "f=" << c << "\n";

afile << "x=" << x << "\n";

afile << "c=" << c << "\n";

afile << "s=" << s << "\n";

// Other
while ( ! afile.eof ( ) )
{ }

afile.close ( );

*/
