PUC-Minas
Instituto de Ci�ncias Exatas e Informatica
Curso de Ci�ncia da Computa��o
Algoritmos e estrutura de dados

Pacote de arquivos para uso e descri��o da biblioteca
acess�ria para lidar com o rob� Karel em linguagem C.

Itens

- karel.h
- karel_docs

Instala��o

O arquivo karel.h poder� ser copiado e usado na
mesma pasta em que estiver o programa a ser 
desenvolvido.

Nesse caso, dever� ser inclu�do no programa
mediante o uso do comando

#include "karel.h"

O arquivo tamb�m poder� ser copiado para a 
pasta .../include do compilador.

Nesse caso, dever� ser inclu�do no programa
mediante o uso do comando

#include <karel.h>

Recomenda-se usar essa �ltima forma, pois
evitar� a repeti��o de c�pias adicionais para
cada nova pasta de programa a ser criada.

Os arquivos com a documenta��o poder�o ser
colocados em qualquer pasta de f�cil acesso 
para consulta. Sugere-se a sua leitura pr�via.


Observa��es

A biblioteca ser� recompilada toda a vez
que o programa tamb�m o for.

Favor informar sobre eventuais problemas,
a fim de depurar o recurso em suas vers�es
futuras.
