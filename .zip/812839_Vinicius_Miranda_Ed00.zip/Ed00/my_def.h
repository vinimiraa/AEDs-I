// Digitar o conteudo abaixo em um arquivo com o nome my_string.h :
// DEFINICOES GLOBAIS
#define EOL '\n'
#define EOS '\0'
// CONSTANTES GLOBAIS
 const int STR_SIZE = 80; // quantidade maxima de caracteres
// TIPOS GLOBAIS
 typedef char* chars; // tipo similar 'a cadeia de caracteres
 