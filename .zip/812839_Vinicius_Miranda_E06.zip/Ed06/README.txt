# Exercicios06

No exercicios 0620, o "metodo0620" esta recursivo, porém ele não está com a soma final dando o valor certo, eu acredito que a minha lógica esteja certa, mas não consegui encontrar onde eu estava errando ou se está faltando alguma coisa. 