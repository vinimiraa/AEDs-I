# Exercicios

 Todos os exercicos, e os extras, foram feitos em um unico arquivo chamado "Exercicios01.c".
