#include "cell.h"

int main ( void )
{
    intCell_test ( );
	
    printf ( "\n" );
    getchar( );
    return ( 0 );
}  // end main ( )