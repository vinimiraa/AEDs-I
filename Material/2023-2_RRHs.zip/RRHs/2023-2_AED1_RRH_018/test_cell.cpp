#include "cell.hpp"

int main ( void )
{
    ref_intCell a = new intCell ( );
    a->test ( );
	
    printf ( "\n" );
    getchar( );
    return ( 0 );
} // end main ( )