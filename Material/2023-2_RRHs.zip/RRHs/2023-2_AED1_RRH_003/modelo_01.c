// 999999 - AED1
#include <stdio.h>
#include <stdlib.h>

int main ( void )
{
 // definir dados e resultados
    
 // identificar
    printf ( "999999 - AED1\n" );
    
 // acoes
    
 // encerrar
    printf ( "\nApertar ENTER para terminar.\n" );
    getchar( );
    return ( 0 );
}
